<!DOCTYPE html>
<!--[if IE 6]>
<html id="ie6" class="ie" lang="en-US" itemscope itemprop="VideoObject" itemtype="https://schema.org/VideoObject">
<![endif]-->
<!--[if IE 7]>
<html id="ie7" class="ie" lang="en-US" itemscope itemprop="VideoObject" itemtype="https://schema.org/VideoObject">
<![endif]-->
<!--[if IE 8]>
<html id="ie8" class="ie" lang="en-US"  itemscope itemprop="VideoObject" itemtype="https://schema.org/VideoObject">
<![endif]-->
<!--[if IE 9]>
<html id="ie9" class="ie" lang="en-US"  itemscope itemprop="VideoObject" itemtype="https://schema.org/VideoObject">
<![endif]-->
<!--[if !(IE 6) | !(IE 7) | !(IE 8) | !(IE 9) ]><!-->
<html lang="en-US" style="margin-top:0!important;"  itemscope itemprop="VideoObject" itemtype="https://schema.org/VideoObject">
<!--<![endif]-->

<head> 

<!--[if lte IE 9]>
	<script type="text/javascript" src="js/respond.min.js"></script>
<![endif]-->

    <!--responsive viewport define here-->
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- meta name="viewport" content="initial-scale=1.0 user-scalable=no"  -->  
    <link rel="dns-prefetch" href="https://khushii.org">
    <link rel="preconnect" href="https://connect.facebook.net/">
    <link rel="preconnect" href="https://www.googletagmanager.com/">
    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="preconnect" href="https://www.facebook.com/">
    <link rel="preconnect" href="https://scontent-bom1-1.cdninstagram.com/">
    <link rel="preconnect" href="https://scontent-bom1-2.cdninstagram.com/">
    
    <meta name="facebook-domain-verification" content="b8hmqchrg187yeurn474z4kb6k00v6" />

    
    
            <link rel="preconnect" href="https://www.youtube.com/">
        <link rel="preconnect" href="https://in.linkedin.com/">
        <link rel="preconnect" href="https://twitter.com/">
    
       

    <!-- preload js and css -->
    <!--  link rel="preload" href="https://khushii.org/wp-content/themes/khushii/css/style6.css" as="style"  -->

  
    <!--fav icon load here--> 
    <link rel="shortcut icon" href="https://khushii.org/wp-content/uploads/2020/10/favicon.png">  
    <link rel="stylesheet" href="https://khushii.org/wp-content/themes/khushii/css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="https://khushii.org/wp-content/themes/khushii/css/style.css?ver2674" type="text/css">
    <link rel="stylesheet" href="https://khushii.org/wp-content/themes/khushii/css/responsive1.css"> 
    <link rel="stylesheet" href="https://khushii.org/wp-content/themes/khushii/css/fancybox.min.css">        
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,800;1,900&display=swap"
        rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Barlow:300,400,500,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Barlow+Semi+Condensed&amp;display=swap" rel="stylesheet">
    <link href="https://khushii.org/wp-content/themes/khushii/css/font-awesome.min.css" rel="stylesheet">
    <link href="https://khushii.org/wp-content/themes/khushii/css/owl.carousel.css" rel="stylesheet">
    
    
    <meta name='robots' content='noindex, follow' />

	<!-- This site is optimized with the Yoast SEO plugin v17.6 - https://yoast.com/wordpress/plugins/seo/ -->
	<title>Page not found - Khushii</title>
	<meta property="og:locale" content="en_US" />
	<meta property="og:title" content="Page not found - Khushii" />
	<meta property="og:site_name" content="Khushii" />
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"WebSite","@id":"https://khushii.org/#website","url":"https://khushii.org/","name":"Khushii","description":"","potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https://khushii.org/?s={search_term_string}"},"query-input":"required name=search_term_string"}],"inLanguage":"en-US"}]}</script>
	<!-- / Yoast SEO plugin. -->


<link rel='dns-prefetch' href='//static.addtoany.com' />
<link rel='dns-prefetch' href='//s.w.org' />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/khushii.org\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.8.6"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([10084,65039,8205,55357,56613],[10084,65039,8203,55357,56613])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css'  href='https://khushii.org/wp-includes/css/dist/block-library/style.min.css?ver=5.8.6' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-css'  href='https://khushii.org/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.5.6' type='text/css' media='all' />
<link rel='stylesheet' id='responsive-lightbox-swipebox-css'  href='https://khushii.org/wp-content/plugins/responsive-lightbox/assets/swipebox/swipebox.min.css?ver=2.3.3' type='text/css' media='all' />
<link rel='stylesheet' id='wp-video-popup-css'  href='https://khushii.org/wp-content/plugins/responsive-youtube-vimeo-popup/assets/css/wp-video-popup.css?ver=2.9.1' type='text/css' media='all' />
<link rel='stylesheet' id='sh-contact-style-css'  href='https://khushii.org/wp-content/plugins/sh-contact-form/css/style.css?ver=5.8.6' type='text/css' media='all' />
<link rel='stylesheet' id='addtoany-css'  href='https://khushii.org/wp-content/plugins/add-to-any/addtoany.min.css?ver=1.15' type='text/css' media='all' />
<script type='text/javascript' id='addtoany-core-js-before'>
window.a2a_config=window.a2a_config||{};a2a_config.callbacks=[];a2a_config.overlays=[];a2a_config.templates={};
</script>
<script type='text/javascript' async src='https://static.addtoany.com/menu/page.js' id='addtoany-core-js'></script>
<script type='text/javascript' src='https://khushii.org/wp-includes/js/jquery/jquery.min.js?ver=3.6.0' id='jquery-core-js'></script>
<script type='text/javascript' src='https://khushii.org/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2' id='jquery-migrate-js'></script>
<script type='text/javascript' async src='https://khushii.org/wp-content/plugins/add-to-any/addtoany.min.js?ver=1.1' id='addtoany-jquery-js'></script>
<script type='text/javascript' src='https://khushii.org/wp-content/plugins/responsive-lightbox/assets/swipebox/jquery.swipebox.min.js?ver=2.3.3' id='responsive-lightbox-swipebox-js'></script>
<script type='text/javascript' src='https://khushii.org/wp-includes/js/underscore.min.js?ver=1.13.1' id='underscore-js'></script>
<script type='text/javascript' src='https://khushii.org/wp-content/plugins/responsive-lightbox/assets/infinitescroll/infinite-scroll.pkgd.min.js?ver=5.8.6' id='responsive-lightbox-infinite-scroll-js'></script>
<script type='text/javascript' id='responsive-lightbox-js-extra'>
/* <![CDATA[ */
var rlArgs = {"script":"swipebox","selector":"lightbox","customEvents":"","activeGalleries":"1","animation":"1","hideCloseButtonOnMobile":"0","removeBarsOnMobile":"0","hideBars":"1","hideBarsDelay":"5000","videoMaxWidth":"1080","useSVG":"1","loopAtEnd":"0","woocommerce_gallery":"0","ajaxurl":"https:\/\/khushii.org\/wp-admin\/admin-ajax.php","nonce":"a3cee0a032"};
/* ]]> */
</script>
<script type='text/javascript' src='https://khushii.org/wp-content/plugins/responsive-lightbox/js/front.js?ver=2.3.3' id='responsive-lightbox-js'></script>
<script type='text/javascript' id='sh-contact-script-js-extra'>
/* <![CDATA[ */
var shcontactAjax = {"ajaxurl":"https:\/\/khushii.org\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type='text/javascript' src='https://khushii.org/wp-content/plugins/sh-contact-form/js/contact_ajax.js?ver=5.8.6' id='sh-contact-script-js'></script>
<script type='text/javascript' id='ajax_comment-js-extra'>
/* <![CDATA[ */
var misha_ajax_comment_params = {"ajaxurl":"https:\/\/khushii.org\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type='text/javascript' src='https://khushii.org/wp-content/themes/khushii/ajax-comments.js?ver=5.8.6' id='ajax_comment-js'></script>
<link rel="https://api.w.org/" href="https://khushii.org/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://khushii.org/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://khushii.org/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.8.6" />
<!-- Global site tag (gtag.js) - Google Ads: 318963435 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-318963435"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-318963435');
</script>

<!-- Facebook Pixel Code -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '177213607849465');
  fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
  src="https://www.facebook.com/tr?id=177213607849465&ev=PageView&noscript=1"
/></noscript>
<!-- End Facebook Pixel Code -->      <meta name="onesignal" content="wordpress-plugin"/>
            <script>

      window.OneSignal = window.OneSignal || [];

      OneSignal.push( function() {
        OneSignal.SERVICE_WORKER_UPDATER_PATH = 'OneSignalSDKUpdaterWorker.js';
                      OneSignal.SERVICE_WORKER_PATH = 'OneSignalSDKWorker.js';
                      OneSignal.SERVICE_WORKER_PARAM = { scope: '/wp-content/plugins/onesignal-free-web-push-notifications/sdk_files/push/onesignal/' };
        OneSignal.setDefaultNotificationUrl("https://khushii.org");
        var oneSignal_options = {};
        window._oneSignalInitOptions = oneSignal_options;

        oneSignal_options['wordpress'] = true;
oneSignal_options['appId'] = 'c29a2283-fd18-412c-a61b-1cffa6af8290';
oneSignal_options['allowLocalhostAsSecureOrigin'] = true;
oneSignal_options['welcomeNotification'] = { };
oneSignal_options['welcomeNotification']['disable'] = true;
oneSignal_options['path'] = "https://khushii.org/wp-content/plugins/onesignal-free-web-push-notifications/sdk_files/";
oneSignal_options['safari_web_id'] = "web.onesignal.auto.28671d66-3da8-4a50-bcc4-1b29e015670b";
oneSignal_options['promptOptions'] = { };
oneSignal_options['notifyButton'] = { };
oneSignal_options['notifyButton']['enable'] = true;
oneSignal_options['notifyButton']['position'] = 'bottom-right';
oneSignal_options['notifyButton']['theme'] = 'default';
oneSignal_options['notifyButton']['size'] = 'medium';
oneSignal_options['notifyButton']['showCredit'] = true;
oneSignal_options['notifyButton']['text'] = {};
                OneSignal.init(window._oneSignalInitOptions);
                OneSignal.showSlidedownPrompt();      });

      function documentInitOneSignal() {
        var oneSignal_elements = document.getElementsByClassName("OneSignal-prompt");

        var oneSignalLinkClickHandler = function(event) { OneSignal.push(['registerForPushNotifications']); event.preventDefault(); };        for(var i = 0; i < oneSignal_elements.length; i++)
          oneSignal_elements[i].addEventListener('click', oneSignalLinkClickHandler, false);
      }

      if (document.readyState === 'complete') {
           documentInitOneSignal();
      }
      else {
           window.addEventListener("load", function(event){
               documentInitOneSignal();
          });
      }
    </script>
<link rel="icon" href="https://khushii.org/wp-content/uploads/2020/10/favicon.png" sizes="32x32" />
<link rel="icon" href="https://khushii.org/wp-content/uploads/2020/10/favicon.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://khushii.org/wp-content/uploads/2020/10/favicon.png" />
<meta name="msapplication-TileImage" content="https://khushii.org/wp-content/uploads/2020/10/favicon.png" />
		<style type="text/css" id="wp-custom-css">
			.thankyoubannerm{padding: 25px;
  background: url('https://khushii.org/wp-content/uploads/2022/02/ty-bd-donate.png');
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;}

.transactionfailm{padding: 25px;
  background: url('https://khushii.org/wp-content/uploads/2022/02/tf-bd-donate.png');
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;}


.transactionfailm a{
    border: 1px solid #ffffff !important;
	  border-radius: 50px !important;
    display: inline-block;
    padding: 5px 50px;
    color: #57b5dd;
    margin: 30px 0;
    font-weight: 500;
    background-color: #ffffff;
}


.transactionfailm h1{
    padding: 5px 20px;
	  font-size:4em;
	line-height:1.1em;
    color: #854f0a;
    margin: 30px 0 10px 0;
    font-weight: 900;
	text-align:center;
}


@media only screen and (max-width: 550px) {
.transactionfailm a{
    border: 1px solid #ffffff !important;
    display: inline-block;
    padding: 5px 20px !important;
    color: #57b5dd;
    margin: 5px 0;
    font-weight: 500;
    background-color: #ffffff;
	}}




		</style>
		 
    
   
    
</head>

<body class="error404 wp-custom-logo">

    <div class="wrapper">
        <header>

            <div class="container desktop-menu">
                <div class="row">
                    <div class="col span_6">&nbsp;</div>
                    <div class="col span_6">
                        <div class="header-contact-div">
                            <div class="header-contact">
                                <ul>
                                    <li><a href=tel:011-41410075>011-41410075/76</a></li>
                                    <li><a href="/cdn-cgi/l/email-protection#6b0804051f0a081f2b00031e180302024504190c"><span class="__cf_email__" data-cfemail="debdb1b0aabfbdaa9eb5b6abadb6b7b7f0b1acb9">[email&#160;protected]</span></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="header-nav">
                    <ol class="">
                        <li><a href="https://khushii.org/who-we-are/">WHO WE ARE</a>
                            <span class="headerarrow">&gt;</span>
                            <ul class="nested level-1">
                                <li><a href="https://khushii.org/who-we-are/">About</a></li>
                                <li><a href="https://khushii.org/who-we-are/leadership/">Leadership</a>
                           <span class="headerarrowL2">&gt;</span>
                                    <ul class="nested level-2">
                                        <li><a href="https://khushii.org/who-we-are/leadership-2/">President - Global</a></li>
                                   </ul>     
                                        
                                </li>
                                <li><a href="https://khushii.org/who-we-are/#all-sec-sec">Partners</a></li>
                                <li><a href="https://khushii.org/who-we-are/#awards_here">Awards & Accreditations</a>
                                </li>
                            </ul>
                        </li>
                        <li><a href="https://khushii.org/what-we-do/education/">WHAT WE DO</a>
                            <span class="headerarrow">&gt;</span>
                            <ul class="nested level-1">
                                <li><a href="https://khushii.org/what-we-do/covid-response/">Covid Response</a></li>
                                <li><a href="https://khushii.org/what-we-do/education/">Education</a>
                                    <span class="headerarrowL2">&gt;</span>
                                    <ul class="nested level-2">
                                        <li><a href="https://khushii.org/what-we-do/education/swatantra-shikshaantra/">Swatantra Shikshaantra</a></li>
                                        <li><a href="https://khushii.org/what-we-do/education/shikshaantra-plus/">Shikshaantra PLUS</a></li>
                                    </ul>
                                </li>
                                <li><a href="https://khushii.org/kite-volunteer/">Volunteer</a></li>
                                <li><a href="https://khushii.org/what-we-do/wellbeing/">Wellbeing</a>
                                </li>
                                <li><a href="https://khushii.org/what-we-do/community-empowerment/">Community-Empowerment</a>
                                    <span class="headerarrowL2">&gt;</span>
                                    <ul class="nested level-2">
                                        <li><a href="https://khushii.org/what-we-do/wellbeing/shiksha-aur-vikas/">Shiksha aur Vikas</a></li>
                                        <li><a href="https://khushii.org/what-we-do/community-empowerment/kala/">Kala</a></li>
                                        </li>
                                    </ul>
                                </li>
                                <li><a href="https://khushii.org/what-we-do/success-stories/">Success Stories</a></li>
                            </ul>
                        </li>
                        <li><a href="https://khushii.org/arts-events/new-event/">ARTS & EVENTS</a>
                            <span class="headerarrow">&gt;</span>
                            <ul class="nested level-1">
                                <li><a href="https://khushii.org/arts-events/new-event/">Events</a></li>
                          <li><a href="https://khushii.org/arts-events/artworks/">Artworks of the month</a></li>      
                                
                                
                                
                                
                          <!--      <li><a href="https://khushii.org/?page_id=245">Monthly Curation</a></li>  -->
                            </ul>
                        </li>
                        <li class="logo">
                            <a href="https://khushii.org/home/"><img src="https://khushii.org/wp-content/uploads/2020/10/main-logo.png"></a>
                        </li>
                        <li><a href="https://khushii.org/resources/annual-reports/">RESOURCES</a>
                            <span class="headerarrow">&gt;</span>
                            <ul class="nested level-1">
                                <li><a href="https://khushii.org/resources/annual-reports/">Annual Reports</a></li>
                                <li><a href="https://khushii.org/resources/annual-reports/fcra-reports/">FCRA Reports</a></li>
                                <li><a href="https://khushii.org/newsletter/">Newsletter</a></li>
                                <li><a href="https://khushii.org/blog/">Blog</a></li>   
                            </ul>
                        </li>
                        <li><a href="https://khushii.org/galleries/">GALLERY</a>   
                            <!-- <span class="headerarrow">&gt;</span>
                                <ul class="nested level-1">
                                    <li><a href="">Images</a></li>
                                    <li><a href="">Videos</a></li>
                                </ul>-->
                        </li>
                        <li><a href="https://khushii.org/contact/">CONTACT</a></li>
                        <li class="button-donate"><a href="https://khushii.org/donation/">DONATE</a>
                        <ul style="display:none;">
                        <!-- <li><a href="https://www.khushii.org/donation/">Education</a></li>  
                        <li><a href="https://www.khushii.org/covid-care-centre/">Covid</a></li>   
                        <li><a href="https://www.khushii.org/covid-emergency-appeal/">Oxygen Concentrator</a></li>   -->
                        <li><a href="https://khushii.org/donation/?source=HPB">Support Education</a></li>
                        <li><a href="https://khushii.org/helpindiaheal/?source=HIH_HPB">Help India Heal</a></li>
                        </ul>
                    </li>

                    </ol>
                </div>

            </div>

            <div class="mobile-menu">
                <div id="mobile-nav">

                    <div class="menu-button">
                        <button id="mainNavBurger" class="burger">
                            <span></span>
                            <span></span>
                            <span></span>
                        </button>
                    </div>
                    <ul>
                       
                        <li class="parent">
                            <a href="https://khushii.org/who-we-are/">WHO WE ARE</a>
                            <ul>
                                <li><a href="https://khushii.org/who-we-are/">About</a></li>
                                <li class="parent"><a href="https://khushii.org/who-we-are/leadership/">Leadership</a>
                               
                                    <ul>
                                        <li><a href="https://khushii.org/who-we-are/leadership-2/">President - Global</a></li>
                                   </ul>    
                                
                                </li>
                                <li><a href="https://khushii.org/who-we-are/#all-sec-sec">Partners</a></li>
                                <li><a href="https://khushii.org/who-we-are/#awards_here">Awards & Accreditations</a></li>
                            </ul>
                        </li>
                        <li class="parent">
                            <a href="https://khushii.org/what-we-do/education/">WHAT WE DO</a>
                            <ul>
                              <li><a href="https://khushii.org/what-we-do/covid-response/">Covid Response</a></li>
                                <li class="parent">
                                    <a href="https://khushii.org/what-we-do/education/">Education</a>
                                    <ul>
                                        <li><a href="https://khushii.org/what-we-do/education/swatantra-shikshaantra/">Swatantra Shikshaantra</a></li>
                                        <li><a href="https://khushii.org/what-we-do/education/shikshaantra-plus/">Shikshaantra PLUS</a></li>
                                    </ul>
                                </li>
                                <li><a href="https://khushii.org/kite-volunteer/">Volunteer</a></li>
                                <li>
                                    <a href="https://khushii.org/what-we-do/wellbeing/">Wellbeing</a>
                                </li>
                                <li class="parent">
                                    <a href="https://khushii.org/what-we-do/community-empowerment/">Community-Empowerment</a>
                                    <ul>
                                        <li><a href="https://khushii.org/what-we-do/community-empowerment/kala/">Kala</a></li>
                                        <li><a href="https://khushii.org/what-we-do/wellbeing/shiksha-aur-vikas/">Shiksha aur Vikas</a></li>
                                    </ul>
                                </li>
                                <li><a href="https://khushii.org/what-we-do/success-stories/">Success Stories</a></li>
                            </ul>
                        </li>
                        <li class="parent">
                            <a href="https://khushii.org/arts-events/new-event/">ARTS & EVENTS</a>
                            <ul>
                                <li><a href="https://khushii.org/arts-events/new-event/">Events</a></li>
                            <li><a href="https://khushii.org/arts-events/artworks/">Artworks of the month</a></li>        
                                
                           <!--     <li><a href="https://khushii.org/?page_id=245">Monthly Curation</a></li>  -->
                            </ul>
                        </li>
                        <li class="parent">
                            <a href="https://khushii.org/resources/annual-reports/">RESOURCES</a>
                            <ul>
                                <li><a href="https://khushii.org/resources/annual-reports/">Annual Reports</a></li>
                                <li><a href="https://khushii.org/resources/annual-reports/fcra-reports/">FCRA Reports</a></li>
                                <li><a href="https://khushii.org/newsletter/">Quarterly Newsletter</a></li>
                                <li><a href="https://khushii.org/blog/">Blog</a></li>
                            </ul>
                        </li>
                        <li><a href="https://khushii.org/galleries/">GALLERY</a></li>
                        <li><a href="https://khushii.org/contact/">CONTACT</a></li>
                    </ul>
                </div>
                
         
        <div class="right-side-menu">
            <div class="logo">
                <a href="https://khushii.org/home/"><img src="https://khushii.org/wp-content/uploads/2020/10/main-logo.png"></a>
                </div>
                <div class="button-donate"><a href="https://khushii.org/donation/ ">DONATE</a></div>
                </div>
            </div>
        </div>
    </header>
<div class="not_found" style="margin-top: 137px;margin-bottom: 30px;">
	<p>Page not found...</p>
</div>

        <footer>
            <div class="donate-sticky">
                <span><a href="https://khushii.org/donation/"><img
                            src="https://khushii.org/wp-content/themes/khushii/images/dontation-hand.png">DONATE</a></span>
                <ul style="display:none;">
                    <!-- <li><a href="https://www.khushii.org/donation/">Education</a></li>
                    <li><a href="https://www.khushii.org/covid-care-centre/">Covid</a></li>   
                    <li><a href="https://www.khushii.org/covid-emergency-appeal/">Oxygen Concentrator</a></li>   -->

                    <li><a href="https://khushii.org/donation/?source=HPB">Support Education</a></li>
                    <li><a href="https://khushii.org/helpindiaheal/?source=HIH_HPB">Help India Heal</a></li>
                </ul>
            </div>
            <div class="footer-form">
                <div class="row">
                    <div class="col span_3 involved">
                        <div class="footer-form-content">
                            <h4><span>GET INVOLVED <span><img
                                            src="https://khushii.org/wp-content/themes/khushii/images/arrow-donate.png"></span>
                                    </sapi_windows_cp_conv>
                            </h4>
                        </div>
                    </div>
                    <div class="col span_3 touch">
                        <div class="footer-form-content">
                            <p><a href="https://khushii.org/contact/"><span><img
                                            src="https://khushii.org/wp-content/themes/khushii/images/touch.png"></span>GET
                                    IN TOUCH </a></p>
                        </div>
                    </div>
                    <div class="col span_3 volunteer">
                        <div class="footer-form-content">
                            <p><a href="https://khushii.org/contact/#contactform"><span><img
                                            src="https://khushii.org/wp-content/themes/khushii/images/volainter.png"></span>BECOME
                                    A VOLUNTEER </a></p>
                        </div>
                    </div>
                    <div class="col span_3 donate">
                        <div class="footer-form-content">
                            <p><a href="https://khushii.org/donation/"><span><img
                                            src="https://khushii.org/wp-content/themes/khushii/images/donate.png"></span>DONATE
                                    NOW </a></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="main-footer">
                <div class="container">
                    <div class="footer-social">
                        <div class="row">
                            <div class="col span_3">
                                <div class="footer-logo">
                                    <a href="https://khushii.org"><img
                                            src="https://khushii.org/wp-content/themes/khushii/images/main-logo.png"></a>
                                </div>
                            </div>
                            <div class="col span_3">
                                <div class="footer-contact">
                                    <h4><a href="tel:011-41410075"><img
                                                src="https://khushii.org/wp-content/themes/khushii/images/phone.png">Call us
                                            now</a> </h4>
                                    <p><a href="tel:011-41410075">011-41410075/76</a></p>
                                </div>
                            </div>
                            <div class="col span_3">
                                <div class="footer-contact">
                                    <h4><a href="/cdn-cgi/l/email-protection#75161a1b01141601351e1d00061d1c1c5b1a0712"><img
                                                src="https://khushii.org/wp-content/themes/khushii/images/mail.png">SEND AN
                                            EMAIL</a> </h4>
                                    <p><a href="/cdn-cgi/l/email-protection#482b27263c292b3c0823203d3b20212166273a2f"><span class="__cf_email__" data-cfemail="e784888993868493a78c8f92948f8e8ec9889580">[email&#160;protected]</span></a></p>
                                </div>
                            </div>
                            <div class="col span_3">
                                <div class="footer-contact">
                                    <h4>CONNECT WITH US </h4>
                                    <ul>
                                        <li><a href="https://www.facebook.com/KhushiiNGO/" target="_blank"><img
                                                    src="https://khushii.org/wp-content/themes/khushii/images/facebook-logo.png"
                                                    target="_blank"></a></li>
                                        <li><a href="https://www.instagram.com/khushii.india/" target="_blank"><img
                                                    src="https://khushii.org/wp-content/themes/khushii/images/instagram-logo.png"></a>
                                        </li>
                                        <li><a href="https://in.linkedin.com/company/khushii-ngo" target="_blank"><img
                                                    src="https://khushii.org/wp-content/themes/khushii/images/linkedin-logo.png"></a>
                                        </li>
                                        <li><a href="https://twitter.com/KhushiiNGO" target="_blank"><img
                                                    src="https://khushii.org/wp-content/themes/khushii/images/twitter.png"></a>
                                        </li>
                                        <li><a href="https://www.youtube.com/channel/UCopwhtiPmta6N2OO934_Fag"
                                                target="_blank"><img
                                                    src="https://khushii.org/wp-content/themes/khushii/images/social-media.png"></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="footer-link-div">
                        <div class="row">
                            <div class="col span_3">
                                <div class="footer-link-content">
                                    <p>Kinship for Humanitarian Social and Holistic Intervention in India (KHUSHII) is
                                        an independent Not for Profit Organisation founded in 2003 by Cricket legend Mr.
                                        Kapil Dev and his philanthropic partners.</p>
                                </div>
                            </div>
                            <div class="col span_3">
                                <div class="footer-link">
                                    <ul>
                                        <li>
                                            <h4>QUICK LINKS</h4>
                                        </li>
                                        <li><a href="#"></a></li>
                                        <li><a href="https://khushii.org/who-we-are/leadership/">Leadership</a></li>
                                        <li><a href="https://khushii.org/what-we-do/covid-response/">Covid Response</a></li>
                                        <li><a href="https://khushii.org/careers/">CAREER</a></li>
                                        <li><a href="https://khushii.org/privacy-policy-2/">Privacy Policy</a></li>

                                    </ul>
                                </div>
                            </div>
                            <div class="col span_3">
                                <div class="footer-link">
                                    <ul>
                                        <li><a href="https://khushii.org/?page_id=245">ARTS & EVENTS</a></li>
                                        <li><a href="https://khushii.org/what-we-do/success-stories/">SUCCESS STORIES</a></li>
                                        <li><a href="https://khushii.org/galleries/">GALLERY</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col span_3">
                                <div class="footer-link">
                                    <ul>
                                        <li>
                                            <h4>GET UPDATES</h4>
                                        </li>
                                        <li>
                                            <p>Keep up with the latest news of our charity organization.</p>
                                        </li>
                                    </ul>
                                    <div class="main-footer-form">
                                        <form id="newsletterr_frm">
                                            <div class="input-div">
                                                <input type="text" id="email_subscription"
                                                    placeholder="ENTER EMAIL ADDRESS">
                                                <div id="response"></div>
                                                <button name="submit_subscription" id="submit_subscription"
                                                    title="Subscribe">SUBSCRIBE</button>
                                            </div>
                                        </form>
                                    </div>



                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-copyright">
                <ul>
                    <li>Copyright © 2023, All Rights Reserved | <a href="#">Digital Impressions</a>
                    </li>
                </ul>
            </div>
        </footer>
        </div> <!-- close wrapper dive-->

        <!-- Global site tag (gtag.js) - Google Analytics -->
        <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script async src="https://www.googletagmanager.com/gtag/js?id=G-NYJG6MLCHL"></script>
        <script>
            window.dataLayer = window.dataLayer || [];

            function gtag() {
                dataLayer.push(arguments);
            }
            gtag('js', new Date());

            gtag('config', 'G-NYJG6MLCHL');
        </script>

        <!-- old tag
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-55663044-1
    "></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());

      gtag('config', 'UA-55663044-1');
    </script>
    -->
        <!-- Facebook Pixel Code -->
        <script>
            ! function (f, b, e, v, n, t, s) {
                if (f.fbq) return;
                n = f.fbq = function () {
                    n.callMethod ?
                        n.callMethod.apply(n, arguments) : n.queue.push(arguments)
                };
                if (!f._fbq) f._fbq = n;
                n.push = n;
                n.loaded = !0;
                n.version = '2.0';
                n.queue = [];
                t = b.createElement(e);
                t.async = !0;
                t.src = v;
                s = b.getElementsByTagName(e)[0];  
                s.parentNode.insertBefore(t, s)
            }(window, document, 'script',
                'https://connect.facebook.net/en_US/fbevents.js');
            fbq('init', '750031515613466');
            fbq('track', 'PageView');
        </script>
        <noscript>
            <img height="1" width="1" src="https://www.facebook.com/tr?id=750031515613466&ev=PageView
    &noscript=1" />
        </noscript>
        <!-- End Facebook Pixel Code -->   

        <!--include all java script file before closing body tag-->
        <script type="text/javascript" src="https://khushii.org/wp-content/themes/khushii/js/jquery-2.1.4.min.js"></script>
        <script type="text/javascript" src="https://khushii.org/wp-content/themes/khushii/js/jquery-migrate-1.2.1.min.js">
        </script>
        <script type="text/javascript" src="https://khushii.org/wp-content/themes/khushii/js/slick.min.js"></script>
        <script type="text/javascript" src="https://khushii.org/wp-content/themes/khushii/js/fancybox.min.js"></script>
        <script type="text/javascript" src="https://khushii.org/wp-content/themes/khushii/js/owl.carousel.min.js"></script>
        <script type="text/javascript"
            src="https://khushii.org/wp-content/themes/khushii/js/custom.js?ver=7721"></script>

                <script async src="https://static.addtoany.com/menu/page.js"></script>
        

        <script type="text/javascript">
            function passport_validate(passport) {
                var regPassport = /^[A-PR-WY][1-9]\d\s?\d{4}[1-9]$/;
                document.getElementById("passport_err").innerHTML = "";
                if (regPassport.test(passport) == false) {
                    document.getElementById("passport_err").innerHTML = "Passport is not yet valid.";
                } else {
                    document.getElementById("passport_err").innerHTML = "";
                }
            }

            function check_foreign_amt() {
                jQuery("input[name=price]").each(function () {
                    jQuery(this).prop("checked", false);
                });
            }

            jQuery(document).ready(function () {

                var foregin_amount = '';
                var price24000 = jQuery("#price24000").val();
                var price12000 = jQuery("#price12000").val();
                var price7200 = jQuery("#price7200").val();

                var price24000_ch = jQuery("#price24000").is(':checked');
                var price12000_ch = jQuery("#price12000").is(':checked');
                var price7200_ch = jQuery("#price7200").is(':checked');
                var yourchoice_ch = jQuery("#yourchoice").is(':checked');

                // jQuery("#yourchoice").click(function(){
                //    jQuery("#custom_amt").show();
                // })

                jQuery("#price24000").click(function () {
                    //jQuery("#custom-price").hide();
                    jQuery("#custom-price").val(price24000);

                })

                jQuery("#price12000").click(function () {
                    //jQuery("#custom-price").hide();
                    jQuery("#custom-price").val(price12000);

                })

                jQuery("#price7200").click(function () {
                    //jQuery("#custom-price").hide();
                    jQuery("#custom-price").val(price7200);
                })
            });

            // function foreign_amt(){
            //   return foregin_amount;
            // }

            jQuery(document).ready(function () {

                jQuery('#submit_subscription').click(function (event) {
                    jQuery('#response').html('');
                    jQuery('#submit_subscription').addClass('click_btn');
                    event.preventDefault();
                    var email = jQuery('#email_subscription').val();
                    jQuery('#submit_subscription').html("PLEASE WAIT...");
                    jQuery('#submit_subscription').prop('disabled', true);
                    jQuery.ajax({
                        method: 'POST',
                        dataType: 'json',
                        data: {
                            'action': 'newsletter_subscribtion',
                            'email': email
                        },
                        url: "https://khushii.org/wp-admin/admin-ajax.php",
                        success: function (result) {
                            //alert(result);
                            //var data=jQuery.parseJSON(result);
                            //console.log(data);
                            jQuery('#submit_subscription').html("SUBSCRIBE");
                            jQuery('#submit_subscription').prop('disabled', false);
                            if (result.msg == 'empty') {
                                jQuery('#response').html('<span class="subs-error">' +
                                    result.message + '</span>');
                                jQuery('#submit_subscription').removeClass('click_btn');
                            }
                            if (result.msg == 'invalid') {
                                jQuery('#submit_subscription').removeClass('click_btn');
                                jQuery('#response').html('<span class="subs-error">' +
                                    result.message + '</span>');
                            }
                            if (result.msg == 'success') {
                                jQuery('#submit_subscription').removeClass('click_btn');
                                jQuery('#response').html('<span class="subs-success">' +
                                    result.message + '</span>');
                                jQuery('#newsletterr_frm')[0].reset();
                                //setTimeout("location.reload(true);", 3000)
                            }
                            if (result.msg == 'already_subscribed') {
                                jQuery('#submit_subscription').removeClass('click_btn');
                                jQuery('#response').html('<span class="subs-success">' +
                                    result.message + '</span>');
                            }
                        }
                    }); // ajax close
                }); // submit subscription close

                jQuery('#voluenter_frm').submit(function (event) {
                    // jQuery('#response').html('');
                    event.preventDefault();
                    // Disable #x
                    jQuery(".v_form_submit").prop("disabled", true);
                    jQuery("#field_error_v_name").text('');
                    jQuery("#field_error_v_email").text('');
                    jQuery("#field_error_v_masters").text('');
                    jQuery("#field_error_v_resume").text('');
                    jQuery("#field_error_v_phone").text('');
                    jQuery('#v_name').removeClass('border_focus_eror');
                    jQuery('#v_email').removeClass('border_focus_eror');
                    jQuery('#v_phone').removeClass('border_focus_eror');
                    jQuery('#v_classes').removeClass('border_focus_eror');

                    //console.log('form submit');
                    var v_name = jQuery('#v_name').val();
                    var v_email = jQuery('#v_email').val();
                    var v_phone = jQuery('#v_phone').val();
                    var v_classes = jQuery('#v_classes:checked').val();
                    var qualification = jQuery('input[name=user_qualification]:checked').val();
                    var v_masters = jQuery('#v_masters:checked').val();
                    //var v_resume = jQuery('#v_resume').val();
                    // var v_resume = jQuery(document).find('input[type="file"]');
                    //var v_resume_file = v_resume[0].files[0];
                    var file_data = jQuery('#v_resume').prop('files')[0];
                    // var qualification;
                    // if (v_classes != 'undefined') {
                    //   qualification = v_classes;
                    // }else if(v_graduation != 'undefined'){
                    //   qualification = v_graduation;
                    // }else{
                    //   qualification = v_masters;
                    // }
                    form_data = new FormData(); // Currently empty
                    form_data.append('action', 'volunteer_form_submit');
                    form_data.append('file', file_data);
                    form_data.append('v_name', v_name);
                    form_data.append('v_email', v_email);
                    form_data.append('v_phone', v_phone);
                    form_data.append('qualification', qualification);

                    jQuery('.v_form_submit').val("PLEASE WAIT...");

                    jQuery.ajax({
                        type: 'POST',
                        url: "https://khushii.org/wp-admin/admin-ajax.php",
                        dataType: 'json',
                        //data:{ 'action': 'volunteer_form_submit','v_name':v_name,'v_email':v_email,'v_phone':v_phone,'qualification':qualification,'v_resume':v_resume_file},
                        contentType: false,
                        processData: false,
                        data: form_data,

                        success: function (response) {
                            jQuery("#v-form-status").show();
                            if (response.type == "success") {
                                // Enable v_form_submit
                                jQuery(".v_form_submit").prop("disabled", false);
                                //alert(response.type)
                                jQuery('.v_form_submit').val("Submit");
                                jQuery(".pls_wait_contact").text('');
                                jQuery("#v-form-status").show();
                                jQuery("#v-form-status").addClass("success-volunteer");
                                jQuery('#voluenter_frm')[0].reset();
                                jQuery("#v-form-status").html(response.text);
                                setTimeout(function () {
                                    location.reload();
                                }, 7000);
                            } else if (response.type == "error") {
                                // Enable v_form_submit
                                jQuery(".v_form_submit").prop("disabled", false);
                                jQuery('.v_form_submit').val("Submit");
                                var v_errors_fields = response.text;
                                var v_errors_fields_ar = v_errors_fields.split(
                                ', '); // split string on comma space
                                console.log(v_errors_fields_ar);
                                if (v_errors_fields_ar.includes("v_name")) {
                                    jQuery("#field_error_v_name").text(
                                        'Name field is required');
                                    jQuery('#v_name').addClass('border_focus_eror');
                                }
                                if (v_errors_fields_ar.includes("v_email")) {
                                    jQuery("#field_error_v_email").text(
                                        'Email field is required');
                                    jQuery('#v_email').addClass('border_focus_eror');
                                }
                                if (v_errors_fields_ar.includes("v_phone")) {
                                    jQuery("#field_error_v_phone").text(
                                        'Phone field is required');
                                    jQuery('#v_phone').addClass('border_focus_eror');
                                }
                                if (v_errors_fields_ar.includes("v_invalid_email")) {
                                    jQuery("#field_error_v_email").text(
                                        'Please enter valid email address');
                                    jQuery('#v_email').addClass('border_focus_eror');
                                }

                                if (v_errors_fields_ar.includes("v_qualification")) {
                                    jQuery("#field_error_v_masters").text(
                                        'Qualification field is required');
                                    //jQuery('#field_error_v_masters').addClass('border_focus_eror');
                                }
                                if (v_errors_fields_ar.includes("v_file_name")) {
                                    jQuery("#field_error_v_resume").text(
                                    'File is required');
                                    //jQuery('#field_error_v_masters').addClass('border_focus_eror');
                                }

                                if (v_errors_fields_ar.includes("v_invalid_file")) {
                                    jQuery("#field_error_v_resume").text(
                                        'Please Upload valid file');
                                    //jQuery('#field_error_v_masters').addClass('border_focus_eror');
                                }



                            }

                        },
                    }); // ajax close
                }); // submit subscription close




                jQuery('#foreign_form').on('submit', function (event) {
                    jQuery('#response').html('');
                    jQuery('#foreign_form').addClass('click_btn');
                    event.preventDefault();

                    jQuery("#amt_err").text('');
                    jQuery("#title_err").text('');
                    jQuery("#fname_err").text('');
                    jQuery("#lname_err").text('');
                    jQuery("#pan_err").text('');
                    jQuery("#email_err").text('');
                    jQuery("#passport_err").text('');
                    jQuery("#phone_err").text('');
                    jQuery("#address_err").text('');
                    jQuery("#country_err").text('');
                    jQuery("#state_err").text('');
                    jQuery("#city_err").text('');
                    jQuery("#zip_err").text('');
                    jQuery("#citizenship_err").text('');

                    jQuery('#amount').removeClass('border_focus_eror');
                    jQuery("#title").removeClass('border_focus_eror');
                    jQuery("#first_name").removeClass('border_focus_eror');
                    jQuery("#last_name").removeClass('border_focus_eror');
                    jQuery("#emailid").removeClass('border_focus_eror');
                    jQuery("#pan").removeClass('border_focus_eror');
                    jQuery("#passport").removeClass('border_focus_eror');
                    jQuery("#address").removeClass('border_focus_eror');
                    jQuery("#phone").removeClass('border_focus_eror');
                    jQuery("#listcountry").removeClass('border_focus_eror');
                    jQuery("#state").removeClass('border_focus_eror');
                    jQuery("#city").removeClass('border_focus_eror');
                    jQuery("#pin").removeClass('border_focus_eror');
                    jQuery("#listiam").removeClass('border_focus_eror');



                    var title = jQuery('#title').val();
                    var first_name = jQuery('#first_name').val();
                    var last_name = jQuery('#last_name').val();
                    var date = jQuery('#date').val();
                    var month = jQuery('#month').val();
                    var year = jQuery('#year').val();
                    var pan = jQuery('#pan').val();
                    var emailid = jQuery('#emailid').val();
                    var passport = jQuery('#passport').val();
                    var phone = jQuery('#phone').val();
                    var address = jQuery('#address').val();
                    var listcountry = jQuery('#listcountry').val();
                    var state = jQuery('#state').val();
                    var city = jQuery('#city').val();
                    var pin = jQuery('#pin').val();
                    var listiam = jQuery('#listiam').val();
                    var add_note = jQuery('#add-note').val();
                    //var amt = jQuery('input[name=price]:checked').val();
                    var amt = jQuery('#custom-price').val();
                    // if (amt == "Amout of your choice") {
                    //     amt = jQuery("#amount").val();
                    // }
                    //console.log(foreign_amt());

                    jQuery('#donate_foriegn').text("PLEASE WAIT...");
                    //jQuery('#donate_foriegn').prop('disabled', true);
                    jQuery.ajax({
                        method: 'POST',
                        dataType: 'json',
                        data: {
                            'action': 'foreign_form_submit',
                            'amount': amt,
                            'title': title,
                            'first_name': first_name,
                            'last_name': last_name,
                            'date': date,
                            'month': month,
                            'year': year,
                            'pan': pan,
                            'email': emailid,
                            'passport': passport,
                            'phone': phone,
                            'address': address,
                            'listcountry': listcountry,
                            'state': state,
                            'city': city,
                            'pin': pin,
                            'listiam': listiam,
                            'add_note': add_note
                        },
                        url: "https://khushii.org/wp-admin/admin-ajax.php",
                        success: function (result) {
                            console.log(result);
                            console.log('hello successlo');
                            // var parse_result = jQuery.parseJSON(result);
                            console.log(result.type);


                            // if (!passport_validate(passport)) {
                            //   return false;
                            // }
                            if (result.type == "success") {
                                // Enable v_form_submit
                                // jQuery( ".v_form_submit" ).prop( "disabled", false ); 
                                //alert(result.type)
                                jQuery(document).find("#redirectforgin [name='encRequest']")
                                    .val(jQuery.trim(result.resp_result));
                                document.redirectforgin.submit();

                                jQuery("#foreign-form-status").show();
                                jQuery("#oreign-form-status").addClass("success-volunteer");
                                jQuery('#foreign_form')[0].reset();
                                //jQuery("#foreign-form-status").html(result.text); 
                                // setTimeout(function() {
                                //   location.reload();
                                // }, 7000);                           
                            } else if (result.type == "error") {
                                var foreign_errors_fields = result.text;
                                var foreign_errors_fields_ar = foreign_errors_fields.split(
                                    ', '); // split string on comma space
                                console.log(foreign_errors_fields_ar);
                                if (foreign_errors_fields_ar.includes("f_amount")) {
                                    jQuery("#amt_err").text('please fill amount');
                                    jQuery('#amount').addClass('border_focus_eror');
                                }
                                if (foreign_errors_fields_ar.includes("f_title")) {
                                    jQuery("#title_err").text('please select title');
                                    jQuery('#title').addClass('border_focus_eror');
                                }
                                if (foreign_errors_fields_ar.includes("f_first_name")) {
                                    jQuery("#fname_err").text('please enter first name');
                                    jQuery('#first_name').addClass('border_focus_eror');
                                }
                                if (foreign_errors_fields_ar.includes("f_last_name")) {
                                    jQuery("#lname_err").text('please enter last name');
                                    jQuery('#last_name').addClass('border_focus_eror');
                                }
                                if (foreign_errors_fields_ar.includes("f_pan")) {
                                    jQuery("#pan_err").text('please enter pan number');
                                    jQuery('#pan').addClass('border_focus_eror');
                                }
                                if (foreign_errors_fields_ar.includes("f_passport")) {
                                    jQuery("#passport_err").text('please enter passport');
                                    jQuery('#f_passport').addClass('border_focus_eror');
                                }
                                if (foreign_errors_fields_ar.includes("f_address")) {
                                    jQuery("#address_err").text('please enter address');
                                    jQuery('#address').addClass('border_focus_eror');
                                }
                                if (foreign_errors_fields_ar.includes("f_listcountry")) {
                                    jQuery("#country_err").text('please select country');
                                    jQuery('#listcountry').addClass('border_focus_eror');
                                }
                                if (foreign_errors_fields_ar.includes("f_state")) {
                                    jQuery("#state_err").text('please enter state');
                                    jQuery('#state').addClass('border_focus_eror');
                                }
                                if (foreign_errors_fields_ar.includes("f_city")) {
                                    jQuery("#city_err").text('please enter city');
                                    jQuery('#city').addClass('border_focus_eror');
                                }
                                if (foreign_errors_fields_ar.includes("f_email")) {
                                    jQuery("#email_err").text('please enter email');
                                    jQuery('#emailid').addClass('border_focus_eror');
                                }
                                if (foreign_errors_fields_ar.includes("f_phone")) {
                                    jQuery("#phone_err").text('please enter phone');
                                    jQuery('#phone').addClass('border_focus_eror');
                                }
                                if (foreign_errors_fields_ar.includes("f_pin")) {
                                    jQuery("#zip_err").text('please enter zip code');
                                    jQuery('#pin').addClass('border_focus_eror');
                                }
                                if (foreign_errors_fields_ar.includes("f_listiam")) {
                                    jQuery("#citizenship_err").text(
                                        'please select citizenship');
                                    jQuery('#listiam').addClass('border_focus_eror');
                                }
                            }
                        }
                    }); // ajax close
                }); // submit subscription close

        heroSlider = jQuery('.hero-slider');
        heroSlider.addClass('owl-carousel');
        heroSlider.owlCarousel({
            items: 1,
            autoplay: true,
            animateIn: 'fadeIn',
            animateOut: 'fadeOut',
            loop: true,
            autoplayHoverPause: true,
            nav: true,
            autoHeight: true,
            navText: [
                '<i class="fa fa-angle-left"></i>',
                '<i class="fa fa-angle-right"></i>'
            ]
        });

        tstSlider = jQuery('.testimonial-slider');
        tstSlider.addClass('owl-carousel');
        tstSlider.owlCarousel({
            items: 3,
            autoplay: true,
            loop: true,
            margin: 30,
            dots: false,
            nav: true,
            navText: [
                '<i class="fa fa-arrow-left"></i>',
                '<i class="fa fa-arrow-right"></i>'
            ],
            responsive: {
                0: {
                    items: 1
                },
                768: {
                    items: 2
                },
                992: {
                    items: 3
                }
            }
        });
            });
        </script>

        <script type="text/javascript" src="https://ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js">
        </script>

        <style type="text/css">
            button#submit_subscription,
            .submit-btn {
                cursor: pointer;

            }

            .click_btn {
                background: #80808073 !important;
            }

            span.subs-error,
            span.subs-success {
                font-size: 13px;
            }

            span.subs-error {
                color: #F44336;
                font-weight: bold;
                font-family: 'Poppins';
            }

            span.subs-success {
                color: #fff;
                font-weight: bold;
                font-family: 'Poppins';
            }

            .pls_wait {
                color: #fff;
                margin-bottom: 10px;
                padding: 4px;
            }

            span.field_error {
                color: red;
                font-family: 'Poppins';
            }

            .border_focus_eror {
                border: 1px red solid !important;
                border-radius: 4px;
            }

            span.cmnt_error {
                position: relative;
                top: -15px;
                color: red;
                font-family: 'Poppins' !important;
            }

            p#comment_msg {
                background: #4CAF50;
                color: #fff;
                padding: 10px;
                border-radius: 4px;
                font-family: 'Poppins';
            }

            span.subs-success {
                color: green;
            }

            .h1class {
                font-size: 24px;
                color: #fff;
                font-weight: bold;
                font-family: Poppins;
            }

            .h1class-img-midlle {
                transform: translate(-50%, -56%);
                position: absolute;
                top: 45%;
                left: 50%;
            }

            .heading {
                font-size: 20px;
                line-height: 1.7;
                margin-bottom: 15px;
                color: #727272;
                font-family: Poppins;
            }

            .changing-lives-head h1 {
                font-size: 40px;
                text-transform: initial;
                letter-spacing: 3.44px;
                font-family: Poppins, sans-serif;
                text-align: center;
                font-weight: 700;
                display: inline-block;
                position: relative;
                margin: 0 0 8px;
                border-bottom: 1px solid #9d9c9c;
            }

            .changing-lives-head h1 a {
                color: #727272 !important;
            }

            .success-volunteer {
                border-radius: 5px;
                background-color: #4CAF50;
                font-family: 'Poppins';
                display: inline-block;
                padding: 10px;
                color: #fff;
                text-align: center;
            }

            #form-row-v {
                display: flex;
                flex-wrap: wrap;
                justify-content: center;
            }

            #apply-now-form input#form-submit {
                cursor: pointer;
            }

            span#field_error_v_resume {
                text-transform: none;
            }

            .donate-sticky ul,
            .header-nav li.button-donate ul {
                position: absolute;
                left: 50%;
                transform: translateX(-50%);
                top: 100%;
                background: #727272;
                padding: 10px 0;
                width: calc(100% + 30px);
                line-height: 2;
                border-top-left-radius: 35px;
                border-bottom-left-radius: 35px;
                display: flex;
                flex-direction: column;
                justify-content: center;
                text-align: center;
            }

            header.fixed li.button-donate ul {
                background: #f8c053;
            }

            .header-nav li.button-donate ul {
                width: 150px;
                border-top-left-radius: 0;
                border-bottom-left-radius: 15px;
                border-bottom-right-radius: 15px;
            }

            .donate-sticky ul a,
            .header-nav li.button-donate ul a {
                color: #fff;
                font-family: 'Poppins';
                text-align: center;
                display: block;
                font-size: 13px;
                font-weight: 400;
            }
        </style>

        </body>

        </html>